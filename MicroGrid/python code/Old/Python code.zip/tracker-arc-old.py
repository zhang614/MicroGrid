from visual import *
from solarTracking import *

#solar panel (3) is 9'9" wide by 6'5" high
#works out the needed height of the pole so that panel does
#not touch the ground when facing dawn on winter solstic (the worst case)
nsDim = 6*12+5
ewDim = 9*12+9 
height = 6*12
width = ewDim/4 #separation of supports in the ew direction

#SUN
sunD = 1000
distant_light(direction=(0,sunD, sunD*cos(winterE)), color=color.white)
#SUN Assamuth angles to design tilt angles
winterMaxA = math.radians(maxElevation(winterSolstice))
winterMaxTilt = winterMaxA + math.radians(10) #don't go all the way down for winter
summerMaxA = math.radians(maxElevation(summerSolstice))
summerMaxTilt = summerMaxA
sweepMax = summerMaxTilt+winterMaxTilt

#GROUND and horizontal support line
#floor = box (pos=(0,0,0), length=4, height=0.5, width=4, color=color.blue)
#floor = box(pos=(0,0,0), length=2*nsDim, height=1, width=2*nsDim, opacity=0.8, materials=materials.rough, color=color.gray(0.6))

radius = nsDim/2
# ground support is the top of the rod grips
# the height above the ground is the bottom of the panel at max winter tilt
supportFrontY =  height-cos(winterMaxTilt)*radius
supportFrontZ = +sin(winterMaxTilt)*radius
supportBackY = height-radius*cos(winterMaxTilt)
supportBackZ = -1*radius*sin(winterMaxTilt)
groundSupportFront = box(pos=(0,supportFrontY,supportFrontZ), length=width*2, height=0.2, width=0.1*nsDim, opacity=0.5, materials = materials.earth)
groundSupportBack = box(pos=(0,supportBackY,supportBackZ), length=width*2, height=0.2, width=0.1*nsDim, opacity=0.5, materials = materials.earth)

#rotate
#(1,0,0) Change x for tilt angle (pitch) #winter to summer
#0,1,0) change y for yaw (not done with panels)
#(0,0,1) change in roll (follow the sun)

#Panel Assemble
panelA = frame()

#panel
panel = box(frame=panelA, pos=(0,height,0), length=ewDim, height=1, width=nsDim, color = color.green) #gray(0.5)) #flat

#SUPPORT arc and struts
grads = 30
angles = [pi/2+i*sweepMax/grads for i in range(0, grads+1)]
supportPointsE = [(width/2,height+radius*cos(x),radius*sin(x)) for x in angles]
supportArcE = curve(frame=panelA, pos=supportPointsE, radius=2, materials = materials.chrome)
supportPointsW = [(-1*width/2,height+radius*cos(x),radius*sin(x)) for x in angles]
supportArcW = curve(frame=panelA, pos=supportPointsW, radius=2, materials = materials.chrome)
#struts
# vertical when winter
strutWitE = cylinder(frame=panelA, pos=(0,height,0), axis=(width/2,-1*sin(winterMaxTilt)*radius,1*cos(winterMaxTilt)*radius),
                    radius=1, materials = materials.chrome)
strutWitW = cylinder(frame=panelA, pos=(0,height,0), axis=(-1*width/2,-1*sin(winterMaxTilt)*radius,1*cos(winterMaxTilt)*radius),
                    radius=1, materials = materials.chrome)
# vertical when summer
strutSumE = cylinder(frame=panelA, pos=(0,height,0), axis=(width/2,-1*sin(summerMaxTilt)*radius,1*cos(summerMaxTilt)*radius),
                    radius=1, materials = materials.chrome)
strutSumW = cylinder(frame=panelA, pos=(0,height,0), axis=(-1*width/2,-1*sin(summerMaxTilt)*radius,1*cos(summerMaxTilt)*radius),
                    radius=1, materials = materials.chrome)
# maximum extent of sweep on the support arc
strutMaxE = cylinder(frame=panelA, pos=(0,height,0), axis=(width/2,-1*sin(sweepMax)*radius,1*cos(sweepMax)*radius),
                    radius=1, materials = materials.chrome)
strutMaxW = cylinder(frame=panelA, pos=(0,height,0), axis=(-1*width/2,-1*sin(sweepMax)*radius,1*cos(sweepMax)*radius),
                    radius=1, materials = materials.chrome)
# down center pole

def trackTheSun(alongVector, steps=100, trackRange=pi/2, origin=(0,height,0)):
    # track the sun, assumes neutral start (noon), returns in same position
    angleIncrement = trackRange/steps
    panelA.rotate(angle=-1*trackRange/2, axis=alongVector, origin=origin) #start in the morning
    #scene.waitfor('click keydown')
    for track in range(0, steps):
        rate(50)
        panelA.rotate(angle=angleIncrement, axis=alongVector, origin=origin)
    #scene.waitfor('click keydown')
    panelA.rotate(angle=-1*trackRange/2, axis=alongVector, origin=origin) #set to neutral
    #scene.waitfor('click keydown')

#tilt rotation

print "winter = "+ str(math.degrees(winterMaxTilt))
print "summer = " + str(math.degrees(summerMaxTilt))
panelCenter = panelA.frame_to_world((0,height,0)) #center for panel frame

trackSteps = 100
trackRange = pi*6/4 #range of the track angle
trackIncrement = trackRange/trackSteps

tiltSteps = 30
tiltRange = summerMaxTilt-winterMaxTilt #summer to winter range
tiltIncrement = tiltRange/tiltSteps
repeats = 100
#print "angle Increment= "+ str(math.degrees(tiltIncrement))
panelA.rotate(angle=pi/2-winterMaxTilt, axis=(1,0,0), origin=panelCenter) #start with winter
tiltAngle = pi/2-winterMaxTilt
for i in range(0, 1):
    for direction in [-1,+1]:
        #scene.waitfor('click keydown')
        for tilt in range(0, tiltSteps):
            rate(20)
            #print "tilt angle "+str(math.degrees(pi/2-tiltAngle))
            tiltAngle = tiltAngle + direction*tiltIncrement
            panelA.rotate(angle=direction*tiltIncrement, axis=(1,0,0), origin=panelCenter) #(1,0,0) Change x for tilt angle
            #trackTheSun((0,cos(tiltAngle),-1*sin(tiltAngle)), 100, pi/2, (0,height,0))
##ball = sphere (pos=(0,4,0), radius=1, color=color.red)
##ball.velocity = vector(0,-1,0)
##dt = 0.01
##
##while 1:
##    rate (100)
##    ball.pos = ball.pos + ball.velocity*dt
##    if ball.y < ball.radius:
##        ball.velocity.y = abs(ball.velocity.y)
##    else:
##        ball.velocity.y = ball.velocity.y - 9.8*dt

##ball.velocity = vector(0,-1,0)
##dt = 0.01
##
##while 1:
##    rate (100)
##    ball.pos = ball.pos + ball.velocity*dt
##    if ball.y < ball.radius:
##        ball.velocity.y = abs(ball.velocity.y)
##    else:
##        ball.velocity.y = ball.velocity.y - 9.8*dt
