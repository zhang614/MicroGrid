import numpy as np
import math
import random as rn
from collections import namedtuple
from loads import *
import numpy as np
from datetime import datetime
from astral import Astral


astral = Astral()
astral.solar_depression = 'civil'
city = astral['Salt Lake City']
def maxElevation(daytime):
    maxE = -1000;
    for hour in range(0, 23):
        daytime = daytime.replace(hour=hour)
        winterE = city.solar_elevation(daytime)
        maxE = max(maxE, winterE)
    return maxE

winterSolstice = datetime(2015, 12, 21)
summerSolstice = datetime(2015, 6, 21)
print maxElevation(winterSolstice)
print maxElevation(summerSolstice)

#solar panel (3) is 9'9" wide by 6'5" high
#works out the needed height of the pole so that panel does
#not touch the ground when facing dawn on winter solstic (the worst case)

length = 9+9/12.0
width = 6+5/12.0
winterE = math.radians(maxElevation(winterSolstice))

#diagonal of panel
diagonal = math.sqrt(math.pow(width/2,2)+math.pow(length/2,2))

print("long side N/S")
nsLength = length
ewLength = width
print("n/s separation="+str(nsLength/math.cos(winterE)))
z=(ewLength/2)/math.tan(winterE)
print("pole height="+str((z+nsLength/2)*math.sin(winterE)))

print("long side E/W")
nsLength = width
ewLength = length
print("n/s separation="+str(nsLength/math.cos(winterE)))
z=(ewLength/2)/math.tan(winterE)
print("pole height="+str((z+nsLength/2)*math.sin(winterE)))


winterE = city.solar_elevation(winterSolstice)
winterA = city.solar_azimuth(winterSolstice)

summerE = city.solar_elevation(summerSolstice)

sun = city.sun(date=winterSolstice, local=True)
riseIndex = (sun['sunrise'].hour*60+sun['sunrise'].minute)/sampleTime
noonIndex = (sun['noon'].hour*60+sun['noon'].minute)/sampleTime
setIndex = (sun['sunset'].hour*60+sun['sunset'].minute)/sampleTime

#power cables
# 3 panels Canadian Solar CS6X-310P > 310 Watt Solar Panel series
# 3 strings parallel
voltage = 36.4
oneVoltage = 3*voltage #max voltage # max current 8.52 A
oneCurrent = 310 / voltage
totalCurrent = 3*oneCurrent
VDI = (totalCurrent*50)/(3*oneVoltage)


print 'Voltage = ' + str(oneVoltage)
print 'Current = ' + str(totalCurrent)
print 'VDI = ' +  str(VDI)

#square feet of panel
area = 9.75 * 6.5
print 'Area = ' + str(area)
print 'height = ' + str(12*7)





